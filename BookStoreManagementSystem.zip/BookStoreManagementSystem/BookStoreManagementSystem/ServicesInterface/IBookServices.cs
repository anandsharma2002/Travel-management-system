﻿using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;

namespace BookStoreManagementSystem.ServicesInterface
{
    public interface IBookServices
    {
        Task<IEnumerable<BookResponseDto>> GetAllBooksAsync();
        Task<IEnumerable<AvailableBookResponseDto>> GetAvailableBooks();
        Task<AvailableBookResponseDto> GetBookByIdAsync(int bookId);
        Task<AvailableBookResponseDto> GetBookAsync(string title, string author);
        Task<BookResponseDto> AddBookAsync(BookRequestDto book);
        Task<BookResponseDto> UpdateBookAsync(int bookId, UpdateBookRequestDto bookRequestDto);
        Task<BookResponseDto> DeleteBookAsync(int bookId);



        
    }
}
