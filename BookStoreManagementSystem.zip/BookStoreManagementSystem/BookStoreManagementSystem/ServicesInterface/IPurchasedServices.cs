﻿using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;

namespace BookStoreManagementSystem.ServicesInterface
{
    public interface IPurchasedServices
    {
        Task<IEnumerable<PurchaseResponseDto>> GetAllPurchasedBooks();
        Task<PurchaseResponseDto> GetPurchasedBookAsync(PurchaseRequestDto purchaseRequestDto, string userName);
        Task<IEnumerable<PurchaseResponseDto>> PurchasedBooks(string userName);
    }
}
