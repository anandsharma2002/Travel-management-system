﻿using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;

namespace BookStoreManagementSystem.ServicesInterface
{
    public interface IBorrowedServices
    {
        Task<BorrowedResponseDto> BorrowBookAsync(BorrowedRequestDto borrowedRequestDto, string userName);
        Task<IEnumerable<BorrowedResponseDto>> BorrowedBooks(string userName);
        Task<BorrowedResponseDto> ReturnBorrowBookAsync(BorrowedRequestDto borrowedRequestDto, string userName);
        Task<IEnumerable<BorrowedResponseDto>> GetAllBorrowedBooks();

    }
}
