﻿using BookStoreManagementSystem.Dto.RequestDto;

namespace BookStoreManagementSystem.Application
{
    public class ApplicationUser : IApplicationUser
    {
        private readonly LoginRequestDto _loginRequestDto;
        public ApplicationUser(LoginRequestDto loginRequestDto)
        {
            _loginRequestDto = loginRequestDto;            
        }
        public async Task<string> LoginUserName()
        {
            var userName = _loginRequestDto.Username;
            return "";
        }
    }
}
