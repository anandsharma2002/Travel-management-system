﻿using System.ComponentModel.DataAnnotations;

namespace BookStoreManagementSystem.Application
{
    public interface IApplicationUser
    {
        Task<string> LoginUserName();
        
    }
}
