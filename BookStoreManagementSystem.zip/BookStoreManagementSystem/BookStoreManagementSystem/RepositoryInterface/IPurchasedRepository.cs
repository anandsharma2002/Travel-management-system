﻿using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;

namespace BookStoreManagementSystem.RepositoryInterface
{
    public interface IPurchasedRepository
    {
        Task<IEnumerable<PurchasedBook>> GetAllPurchasedBooks();
        Task<PurchasedBook> GetPurchasedBookAsync(PurchasedBook purchasedBook);
        Task<IEnumerable<PurchasedBook>> PurchasedBooks(string userName);
    }
}
