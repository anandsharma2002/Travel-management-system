﻿using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;

namespace BookStoreManagementSystem.RepositoryInterface
{
    public interface IBookRepository
    {
        Task<IEnumerable<Book>> GetAllBooksAsync();
        Task<IEnumerable<Book>> GetAvailableBooks();
        Task<Book> GetBookByIdAsync(Book book);
        Task<Book> GetBookAsync(Book book);
        Task<Book> AddBookAsync(Book book);
        Task<Book> UpdateBookAsync(Book book);
        Task<Book> DeleteBookAsync(Book book);
        
        
    }
}
