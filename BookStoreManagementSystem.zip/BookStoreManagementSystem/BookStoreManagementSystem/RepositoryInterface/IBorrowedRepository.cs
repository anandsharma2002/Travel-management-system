﻿using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;

namespace BookStoreManagementSystem.RepositoryInterface
{
    public interface IBorrowedRepository
    {
        Task<BorrowedBook> BorrowBookAsync(BorrowedBook borrowedBook);
        Task<BorrowedBook> GetBorrowedBook(BorrowedBook borrowedBook);
        Task<IEnumerable<BorrowedBook>> BorrowedBooks(string userName);
        Task<BorrowedBook> ReturnBorrowBookAsync(BorrowedBook borrowedBook);
        Task<IEnumerable<BorrowedBook>> GetAllBorrowedBooks();
    }
}
