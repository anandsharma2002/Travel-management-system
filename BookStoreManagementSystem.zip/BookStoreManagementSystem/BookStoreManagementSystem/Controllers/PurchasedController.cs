﻿using BookStoreManagementSystem.ApiResult;
using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Services;
using System.Security.Claims;
using BookStoreManagementSystem.ServicesInterface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookStoreManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PurchasedController : ControllerBase
    {
        private readonly IPurchasedServices _purchasedServices;
        public PurchasedController(IPurchasedServices purchasedServices)
        {
            _purchasedServices = purchasedServices;
        }


        [HttpGet("GetAllBorrowedBooks")]
        //[Authorize(Roles = "User")]
        public async Task<ApiResult<IEnumerable<PurchaseResponseDto>>> GetAllBorrowedBooks()
        {
            var apiResult = new ApiResult<IEnumerable<PurchaseResponseDto>>();

            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Email);
                var content = await _purchasedServices.GetAllPurchasedBooks();
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }



        [HttpPost("GetPurchaseBook")]
        [Authorize(Roles = "User")]
        public async Task<ApiResult<PurchaseResponseDto>> GetPurchaseBook([FromBody] PurchaseRequestDto purchaseBookRequestDto)
        {
            var apiResult = new ApiResult<PurchaseResponseDto>();

            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Email);
                var content = await _purchasedServices.GetPurchasedBookAsync(purchaseBookRequestDto, userName);
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }

        [HttpGet("BorrowedBooks")]
        //[Authorize(Roles = "User")]
        public async Task<ApiResult<IEnumerable<PurchaseResponseDto>>> BorrowedBooks()
        {
            var apiResult = new ApiResult<IEnumerable<PurchaseResponseDto>>();

            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Email);
                //var username = HttpContext.Session.GetString("Username");
                var content = await _purchasedServices.PurchasedBooks(userName);
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }


    }
}
