﻿using BookStoreManagementSystem.Application;
using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.RepositoryInterface;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace BookStoreManagementSystem.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly ITokenRepository _tokenRepository;

        public AuthController(UserManager<IdentityUser> userManager, ITokenRepository tokenRepository)
        {
            _userManager = userManager;
            _tokenRepository = tokenRepository;
        }

        [HttpPost("Regester")]
        public async Task<IActionResult> Regester([FromBody] RegisterRequestDto registerRequestDto)
        {
            var user = new IdentityUser
            {
                UserName = registerRequestDto.UserName,
                Email = registerRequestDto.UserName
            };

            var identityResult = await _userManager.CreateAsync(user, registerRequestDto.Password);
            if (identityResult.Succeeded)
            {
                identityResult = await _userManager.AddToRolesAsync(user, registerRequestDto.Roles);
                if (identityResult.Succeeded)
                {
                    return Ok("Registered successfully.");
                }
            }
            return BadRequest("Wrongggggg");
        }


        [HttpPost("Login")]
        public async Task<IActionResult> Login([FromBody] LoginRequestDto loginRequestDto)
        {
            var user = await _userManager.FindByEmailAsync(loginRequestDto.Username);

            if (user != null)
            {
                var checkPasswordResult = await _userManager.CheckPasswordAsync(user, loginRequestDto.Password);

                if (checkPasswordResult)
                {
                    var roles = await _userManager.GetRolesAsync(user);

                    if (roles != null)
                    {
                        var jwtToken = _tokenRepository.CreateJwtToken(user, roles.ToList());
                        //HttpContext.Session.SetString("Username", loginRequestDto.Username);
                        return Ok(jwtToken);
                    }


                }

            }
            return BadRequest("Wrong UserName or password");
        }
    }
}
