﻿using BookStoreManagementSystem.ApiResult;
using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Services;
using System.Security.Claims;
using BookStoreManagementSystem.ServicesInterface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookStoreManagementSystem.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BorrowedController : ControllerBase
    {
        private readonly IBorrowedServices _borrowedServices;
        public BorrowedController(IBorrowedServices borrowedServices)
        {
            _borrowedServices = borrowedServices;
        }

        [HttpGet("GetAllBorrowedBooks")]
        //[Authorize(Roles = "User")]
        public async Task<ApiResult<IEnumerable<BorrowedResponseDto>>> GetAllBorrowedBooks()
        {
            var apiResult = new ApiResult<IEnumerable<BorrowedResponseDto>>();

            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Email);
                //var username = HttpContext.Session.GetString("Username");
                var content = await _borrowedServices.GetAllBorrowedBooks();
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }


        [HttpPost("BorrowBook")]
        //[Authorize(Roles = "User")]
        public async Task<ApiResult<BorrowedResponseDto>> BorrowBook([FromBody] BorrowedRequestDto borrowedRequestDto)
        {
            var apiResult = new ApiResult<BorrowedResponseDto>();

            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Email);
                var content = await _borrowedServices.BorrowBookAsync(borrowedRequestDto, userName);
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }

        [HttpPut("ReturnBorrowBook")]
        public async Task<ApiResult<BorrowedResponseDto>> ReturnBorrowBook([FromBody] BorrowedRequestDto borrowedRequestDto)
        {
            var apiResult = new ApiResult<BorrowedResponseDto>();

            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Email);
                var content = await _borrowedServices.ReturnBorrowBookAsync(borrowedRequestDto, userName);
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }



        [HttpGet("BorrowedBooks")]
        //[Authorize(Roles = "User")]
        public async Task<ApiResult<IEnumerable<BorrowedResponseDto>>> BorrowedBooks()
        {
            var apiResult = new ApiResult<IEnumerable<BorrowedResponseDto>>();

            try
            {
                var userName = User.FindFirstValue(ClaimTypes.Email);
                //var username = HttpContext.Session.GetString("Username");
                var content = await _borrowedServices.BorrowedBooks(userName);
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }




    }
}
