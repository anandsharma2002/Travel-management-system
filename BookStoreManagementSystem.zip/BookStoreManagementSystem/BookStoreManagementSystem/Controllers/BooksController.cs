﻿using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using BookStoreManagementSystem.ApiResult;
using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;
using BookStoreManagementSystem.ServicesInterface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;

namespace BookStoreManagementSystem.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IBookServices _bookServices;
        public BooksController(IBookServices bookServices)
        {
            _bookServices = bookServices;
        }


        [HttpGet("GetAllBooks")]
        //[Authorize(Roles = "User")]
        public async Task<ApiResult<IEnumerable<BookResponseDto>>> GetAllBooks()
        {
            var apiResult = new ApiResult<IEnumerable<BookResponseDto>>();

            try
            {
                //var username = HttpContext.Session.GetString("Username");
                var content = await _bookServices.GetAllBooksAsync();
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }

        [HttpGet("GetAvailableBooks")]
        //[Authorize(Roles = "User")]
        public async Task<ApiResult<IEnumerable<AvailableBookResponseDto>>> GetAvailableBooks()
        {
            var apiResult = new ApiResult<IEnumerable<AvailableBookResponseDto>>();

            try
            {
                //var username = HttpContext.Session.GetString("Username");
                var content = await _bookServices.GetAvailableBooks();
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }

        [HttpGet("GetBookByBookId/{bookId}")]
        //[Authorize(Roles = "User")]
        public async Task<ApiResult<AvailableBookResponseDto>> GetBookByBookId([FromRoute] int bookId)
        {
            var apiResult = new ApiResult<AvailableBookResponseDto>();

            try
            {
                var content = await _bookServices.GetBookByIdAsync(bookId);
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }

        [HttpGet("GetBookAsync/{title}/{author}")]
        //[Authorize(Roles = "User")]
        public async Task<ApiResult<AvailableBookResponseDto>> GetBook([FromRoute] string title, [FromRoute] string author)
        {
            var apiResult = new ApiResult<AvailableBookResponseDto>();

            try
            {
                var content = await _bookServices.GetBookAsync(title, author);
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }

        [HttpPost("AddBook")]
        public async Task<ApiResult<BookResponseDto>> AddBook([FromBody] BookRequestDto bookRequestDto)
        {
            var apiResult = new ApiResult<BookResponseDto>();

            try
            {

                var content = await _bookServices.AddBookAsync(bookRequestDto);
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.Created;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }

        [HttpPut("UpdateBook/{bookId}")]
        public async Task<ApiResult<BookResponseDto>> UpdateBook([FromRoute] int bookId, [FromBody] UpdateBookRequestDto updateBookRequestDto)
        {
            var apiResult = new ApiResult<BookResponseDto>();

            try
            {
                var content = await _bookServices.UpdateBookAsync(bookId, updateBookRequestDto);
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }


        [HttpDelete("DeleteBookAsync/{bookId}")]
        public async Task<ApiResult<BookResponseDto>> DeleteBookAsync([FromRoute] int bookId)
        {
            var apiResult = new ApiResult<BookResponseDto>();

            try
            {
                var content = await _bookServices.DeleteBookAsync(bookId);
                apiResult.Content = content;
                apiResult.IsSuccess = true;
                apiResult.StatusCode = System.Net.HttpStatusCode.OK;
                return apiResult;
            }
            catch
            {
                apiResult.IsSuccess = false;
                apiResult.StatusCode = System.Net.HttpStatusCode.BadRequest;
                apiResult.ErrorMessage = "Error";
                return apiResult;
            }
        }


        

        


    }
}
