﻿using AutoMapper;
using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;

namespace BookStoreManagementSystem.AutoMapper
{
    public class AutoMapping : Profile
    {
        public AutoMapping() 
        {
            CreateMap<Book, BookResponseDto>().ReverseMap();
            CreateMap<Book, BookRequestDto>().ReverseMap();
            CreateMap<Book, AvailableBookResponseDto>().ReverseMap();
            CreateMap<Book, BorrowedBook>().ReverseMap();

            
            CreateMap<BorrowedBook, BorrowedRequestDto>().ReverseMap();
            CreateMap<BorrowedBook, BorrowedResponseDto>().ReverseMap();


            CreateMap<PurchasedBook, PurchaseRequestDto>().ReverseMap();
            CreateMap<PurchasedBook, PurchaseResponseDto>().ReverseMap();
        }
    }
}
