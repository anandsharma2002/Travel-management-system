﻿namespace BookStoreManagementSystem.Dto.RequestDto
{
    public class ReturnBorrowedBookDto
    {
    }
}
