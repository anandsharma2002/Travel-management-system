﻿namespace BookStoreManagementSystem.Dto.RequestDto
{
    public class PurchaseRequestDto
    {
        public string BookTitle { get; set; }
        public string BookAuthor { get; set; }
        public int Quantity { get; set; }
        public DateOnly PurchasedDate { get; set; }
    }
}
