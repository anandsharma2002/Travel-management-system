﻿namespace BookStoreManagementSystem.Dto.RequestDto
{
    public class BorrowedRequestDto
    {

        public int BookId { get; set; }
        public int BorrowQuantity { get; set; }
        public DateOnly BorrowDate { get; set; }
        public DateOnly ReturnDate { get; set; }
    }
}
