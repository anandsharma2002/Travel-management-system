﻿using System.ComponentModel.DataAnnotations;
using BookStoreManagementSystem.CustomValidation;

namespace BookStoreManagementSystem.Dto.RequestDto
{
    public class BookRequestDto
    {
        [Required]
        [MinLength(2, ErrorMessage = "Title has to be a minimum of 2 characters")]
        public string Title { get; set; }
        [Required]
        [MinLength(2, ErrorMessage = "Author has to be a minimum of 2 characters")]
        public string Author { get; set; }
        [Required]
        [MinLength(2, ErrorMessage = "Category has to be a minimum of 2 characters")]
        public string Category { get; set; }
        [Required]
        public double Price { get; set; }
        [Required]
        public int Quantity { get; set; }
    }
}
