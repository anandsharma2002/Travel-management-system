﻿namespace BookStoreManagementSystem.Dto.ResponseDto
{
    public class BorrowedResponseDto
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string BookTitle { get; set; }
        public string BookAuthor { get; set; }
        public int Quantity { get; set; }
        public DateOnly BorrowedDate { get; set; }
        public DateOnly ReturnDate { get; set; }
        public DateOnly BookReturnedDate { get; set; }
        public bool IsReturned { get; set; }
    }
}
