﻿using BookStoreManagementSystem.Data;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;
using BookStoreManagementSystem.RepositoryInterface;
using Microsoft.EntityFrameworkCore;

namespace BookStoreManagementSystem.Repository
{
    public class BorrowedRepository : IBorrowedRepository
    {
        private readonly BookStoreDbContext _context;
        public BorrowedRepository(BookStoreDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<BorrowedBook>> GetAllBorrowedBooks()
        {
            return  await _context.BorrowedBooks.Include("Book").ToListAsync();
        }

        public async Task<BorrowedBook> GetBorrowedBook(BorrowedBook borrowedBook)
        {
            return await _context.BorrowedBooks.FirstOrDefaultAsync(x=>x.UserName==borrowedBook.UserName&&x.BookId==borrowedBook.BookId);
        }

        public async Task<BorrowedBook> BorrowBookAsync(BorrowedBook borrowedBook)
        {
            await _context.BorrowedBooks.AddAsync(borrowedBook);
            await _context.SaveChangesAsync();
            return await _context.BorrowedBooks.FirstOrDefaultAsync(x => x.BookId.Equals(borrowedBook.BookId) && x.UserName.Equals(borrowedBook.UserName));
        }

        public async Task<BorrowedBook> ReturnBorrowBookAsync(BorrowedBook borrowedBook)
        {
            _context.BorrowedBooks.Update(borrowedBook);
            await _context.SaveChangesAsync();
            return borrowedBook;
        }

        public async Task<IEnumerable<BorrowedBook>> BorrowedBooks(string userName)
        {
            return await _context.BorrowedBooks.Where(x=>x.UserName==userName).Include("Book").ToListAsync();
        }




    }
}
