﻿using BookStoreManagementSystem.Data;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;
using BookStoreManagementSystem.RepositoryInterface;
using Microsoft.EntityFrameworkCore;

namespace BookStoreManagementSystem.Repository
{
    public class BookRepository : IBookRepository
    {
        private readonly BookStoreDbContext _context;
        public BookRepository(BookStoreDbContext context)
        {
            _context = context;
        }


        public async Task<IEnumerable<Book>> GetAllBooksAsync()
        {
            return await _context.Books.ToListAsync();
        }

        public async Task<IEnumerable<Book>> GetAvailableBooks()
        {
            return await _context.Books.Where(x=>x.Available > 0).ToListAsync();
        }

        public async Task<Book> GetBookByIdAsync(Book book)
        {
            return await _context.Books.FirstOrDefaultAsync(x=> x.Id==book.Id);
        }

        public async Task<Book> GetBookAsync(Book book)
        {
            return await _context.Books.FirstOrDefaultAsync(x => x.Title.Equals(book.Title) && x.Author.Equals(book.Author));
        }

        public async Task<Book> AddBookAsync(Book book)
        {
            await _context.Books.AddAsync(book);
            await _context.SaveChangesAsync();
            return await _context.Books.FirstOrDefaultAsync(x => x.Id==book.Id);
        }

        public async Task<Book> UpdateBookAsync(Book book)
        {
            _context.Books.Update(book);
            await _context.SaveChangesAsync();
            return await _context.Books.FirstOrDefaultAsync(x => x.Id == book.Id);
        }

        public async Task<Book> DeleteBookAsync(Book book)
        {
            var deletedBook = await _context.Books.FirstOrDefaultAsync(x => x.Id == book.Id);
            _context.Books.Remove(book);
            await _context.SaveChangesAsync();
            return deletedBook;
        }

        



    }
}
