﻿using BookStoreManagementSystem.Data;
using BookStoreManagementSystem.Models;
using BookStoreManagementSystem.RepositoryInterface;
using Microsoft.EntityFrameworkCore;

namespace BookStoreManagementSystem.Repository
{
    public class PurchasedRepository : IPurchasedRepository
    {

        private readonly BookStoreDbContext _context;
        public PurchasedRepository(BookStoreDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<PurchasedBook>> GetAllPurchasedBooks()
        {
            return await _context.PurchasedBooks.Include("Book").ToListAsync();
        }

        public async Task<PurchasedBook> GetPurchasedBookAsync(PurchasedBook purchasedBook)
        {
            await _context.PurchasedBooks.AddAsync(purchasedBook);
            await _context.SaveChangesAsync();
            return await _context.PurchasedBooks.FirstOrDefaultAsync(x => x.BookId.Equals(purchasedBook.BookId) && x.UserName.Equals(purchasedBook.UserName));
        }

        public async Task<IEnumerable<PurchasedBook>> PurchasedBooks(string userName)
        {
            return await _context.PurchasedBooks.Where(x => x.UserName == userName).Include("Book").ToListAsync();
        }


    }

}
