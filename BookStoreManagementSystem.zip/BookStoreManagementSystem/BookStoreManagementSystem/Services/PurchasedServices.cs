﻿using AutoMapper;
using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;
using BookStoreManagementSystem.Repository;
using BookStoreManagementSystem.RepositoryInterface;
using BookStoreManagementSystem.ServicesInterface;

namespace BookStoreManagementSystem.Services
{
    public class PurchasedServices : IPurchasedServices
    {
        private readonly IBookRepository _bookRepository;
        private readonly IPurchasedRepository _purchasedRepository;
        private readonly IMapper _mapper;

        public PurchasedServices(IPurchasedRepository purchasedRepository, IBookRepository bookRepository, IMapper mapper)
        {
            _purchasedRepository = purchasedRepository;
            _bookRepository = bookRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<PurchaseResponseDto>> GetAllPurchasedBooks()
        {
            var data = await _purchasedRepository.GetAllPurchasedBooks();
            var result = data.Select(
                x => new PurchaseResponseDto
                {
                    Id = x.Id,
                    UserName = x.UserName,
                    BookTitle = x.Book.Title,
                    BookAuthor = x.Book.Author,
                    Quantity = x.Quantity,
                    PurchaseDate = x.PurchasedDate,
                }).ToList();
            return result;
        }


        public async Task<PurchaseResponseDto> GetPurchasedBookAsync(PurchaseRequestDto purchaseRequestDto, string userName)
        {
            var data = new Book
            {
                Title = purchaseRequestDto.BookTitle,
                Author = purchaseRequestDto.BookAuthor
            };
            data = await _bookRepository.GetBookAsync(data);

            var purchasedBook = new PurchasedBook
            {
                UserName = userName,
                BookId = data.Id,
                Quantity = purchaseRequestDto.Quantity,
                PurchasedDate = purchaseRequestDto.PurchasedDate,
            };
            var result = await _purchasedRepository.GetPurchasedBookAsync(purchasedBook);
            return _mapper.Map<PurchaseResponseDto>(result);
        }

        public async Task<IEnumerable<PurchaseResponseDto>> PurchasedBooks(string userName)
        {
            var data = await _purchasedRepository.PurchasedBooks(userName);
            var result = data.Select(
                x => new PurchaseResponseDto
                {
                    Id = x.Id,
                    UserName = x.UserName,
                    BookTitle = x.Book.Title,
                    BookAuthor = x.Book.Author,
                    Quantity = x.Quantity,
                    PurchaseDate = x.PurchasedDate,
                }).ToList();

            return result;
        }

    }
}
