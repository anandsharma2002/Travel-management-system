﻿using System.Net;
using AutoMapper;
using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;
using BookStoreManagementSystem.RepositoryInterface;
using BookStoreManagementSystem.ServicesInterface;

namespace BookStoreManagementSystem.Services
{
    public class BorrowedServices : IBorrowedServices
    {
        private readonly IBookRepository _bookRepository;
        private readonly IBorrowedRepository _borrowedRepository;
        private readonly IMapper _mapper;

        public BorrowedServices(IBookRepository bookRepository, IBorrowedRepository borrowedRepository, IMapper mapper)
        {
            _borrowedRepository = borrowedRepository;
            _bookRepository = bookRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<BorrowedResponseDto>> GetAllBorrowedBooks()
        {
            var data = await _borrowedRepository.GetAllBorrowedBooks();
            return _mapper.Map<IEnumerable<BorrowedResponseDto>>(data);
        }

        public async Task<BorrowedResponseDto> BorrowBookAsync(BorrowedRequestDto borrowedRequestDto, string userName)
        {
            var data = new Book
            {
                Id = borrowedRequestDto.BookId,
            };
            data = await _bookRepository.GetBookByIdAsync(data);
            var borrowedBook = new BorrowedBook
            {
                UserName = userName,
                BookId = data.Id,
                Quantity = borrowedRequestDto.BorrowQuantity,
                BorrowedDate = borrowedRequestDto.BorrowDate,
                ReturnDate = borrowedRequestDto.ReturnDate,
                IsReturned = false
            };

            var result = await _borrowedRepository.BorrowBookAsync(borrowedBook);
            return _mapper.Map<BorrowedResponseDto>(result);
        }


        public async Task<BorrowedResponseDto> ReturnBorrowBookAsync(BorrowedRequestDto borrowedRequestDto, string userName)
        {
            var book = new Book
            {
                Id = borrowedRequestDto.BookId,
            };
            book = await _bookRepository.GetBookByIdAsync(book);
            //var borrowedBook = _mapper.Map<BorrowedBook>(borrowedRequestDto);
            //borrowedBook.UserName = userName;

            var borrowedBook = new BorrowedBook
            {
                UserName = userName,
                BookId = borrowedRequestDto.BookId,
                Quantity = borrowedRequestDto.BorrowQuantity
            };
            var data = await _borrowedRepository.GetBorrowedBook(borrowedBook);
            data.IsReturned = true;
            //data.BookReturnedDate = borrowedRequestDto.ReturnDate;
            data.BookReturnedDate = DateOnly.FromDateTime(DateTime.Now);
            data = await _borrowedRepository.ReturnBorrowBookAsync(data);
            return _mapper.Map<BorrowedResponseDto>(data);
        }

        public async Task<IEnumerable<BorrowedResponseDto>> BorrowedBooks(string userName)
        {
            var data = await _borrowedRepository.BorrowedBooks(userName);
            return _mapper.Map<IEnumerable<BorrowedResponseDto>>(data);
        }



    }
}
