﻿using AutoMapper;
using BookStoreManagementSystem.Dto.RequestDto;
using BookStoreManagementSystem.Dto.ResponseDto;
using BookStoreManagementSystem.Models;
using BookStoreManagementSystem.RepositoryInterface;
using BookStoreManagementSystem.ServicesInterface;
using Microsoft.EntityFrameworkCore;

namespace BookStoreManagementSystem.Services
{
    public class BookServices : IBookServices
    {
        private readonly IBookRepository _bookRepository;
        private readonly IMapper _mapper;

        public BookServices(IBookRepository bookRepository, IMapper mapper)
        {
            _bookRepository = bookRepository;
            _mapper = mapper;
        }

        public async Task<IEnumerable<BookResponseDto>> GetAllBooksAsync()
        {
            var books = await _bookRepository.GetAllBooksAsync();
            return _mapper.Map<IEnumerable<BookResponseDto>>(books);
        }

        public async Task<IEnumerable<AvailableBookResponseDto>> GetAvailableBooks()
        {
            var data = await _bookRepository.GetAvailableBooks();
            return _mapper.Map<IEnumerable<AvailableBookResponseDto>>(data);
        }

        public async Task<AvailableBookResponseDto> GetBookByIdAsync(int bookId)
        {
            var findBook = new Book
            {
                Id = bookId,
            };
            var data = await _bookRepository.GetBookByIdAsync(findBook);
            return _mapper.Map<AvailableBookResponseDto>(data);
        }

        public async Task<AvailableBookResponseDto> GetBookAsync(string title, string author)
        {
            var getBook = new Book
            {
                Title = title,
                Author = author
            };
            var result = await _bookRepository.GetBookAsync(getBook);
            return _mapper.Map<AvailableBookResponseDto>(result);
        }

        public async Task<BookResponseDto> AddBookAsync(BookRequestDto book)
        {
            var newBook = _mapper.Map<Book>(book);
            var getbook = await _bookRepository.GetBookAsync(newBook);
            if (getbook == null)
            {
                newBook.Available = book.Quantity;
                var result = await _bookRepository.AddBookAsync(newBook);
                return _mapper.Map<BookResponseDto>(result);
            }
            return _mapper.Map<BookResponseDto>(getbook);
        }

        public async Task<BookResponseDto> UpdateBookAsync(int bookId, UpdateBookRequestDto  updateBookRequestDto)
        {
            //var newBook = _mapper.Map<Book>(book);
            var newBook = new Book
            {
                Id = bookId,
            };
            var getbook = await _bookRepository.GetBookByIdAsync(newBook);
            if (getbook != null)
            {
                getbook.Title = updateBookRequestDto.Title;
                getbook.Author = updateBookRequestDto.Author;
                getbook.Category = updateBookRequestDto.Category;
                getbook.Price = updateBookRequestDto.Price;
                getbook.Quantity = updateBookRequestDto.Quantity;
                getbook.Available = updateBookRequestDto.Available;
                var result = await _bookRepository.UpdateBookAsync(getbook);
                return _mapper.Map<BookResponseDto>(result);
            }
            return _mapper.Map<BookResponseDto>(getbook);
        }

        public async Task<BookResponseDto> DeleteBookAsync(int bookId)
        {
            //var newBook = _mapper.Map<Book>(book);
            var newBook = new Book
            {
                Id = bookId,
            };
            var getbook = await _bookRepository.GetBookByIdAsync(newBook);
            if (getbook != null)
            {
                var result = await _bookRepository.DeleteBookAsync(getbook);
                return _mapper.Map<BookResponseDto>(result);
            }
            return _mapper.Map<BookResponseDto>(getbook);
        }

        




    }
}
