﻿using Microsoft.AspNetCore.Identity;

namespace BookStoreManagementSystem.Models
{
    public class PurchasedBook
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public int BookId { get; set; }
        public int Quantity { get; set; }
        public DateOnly PurchasedDate { get; set; }

        public Book Book { get; set; }
    }
}
