﻿using Microsoft.AspNetCore.Identity;

namespace BookStoreManagementSystem.Models
{
    public class BorrowedBook
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public int BookId { get; set; }
        public int Quantity { get; set; }
        public DateOnly BorrowedDate { get; set; }
        public DateOnly ReturnDate { get; set; }
        public DateOnly BookReturnedDate { get; set; }
        public bool IsReturned { get; set; }

        public Book Book { get; set; }

    }
}
