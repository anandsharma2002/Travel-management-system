﻿using System.ComponentModel.DataAnnotations;

namespace BookStoreManagementSystem.CustomValidation
{
    public class NotZeroAttribute : ValidationAttribute 
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value is int intValue && intValue == 0)
            {
                return new ValidationResult("The value cannot be zero.");
            }
            return ValidationResult.Success;
        }
    }
}
