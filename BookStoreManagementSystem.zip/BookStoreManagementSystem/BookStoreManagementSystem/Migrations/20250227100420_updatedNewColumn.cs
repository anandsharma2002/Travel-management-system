﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BookStoreManagementSystem.Migrations
{
    /// <inheritdoc />
    public partial class updatedNewColumn : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PurchasedBooks_AspNetUsers_UserId",
                table: "PurchasedBooks");

            migrationBuilder.DropIndex(
                name: "IX_PurchasedBooks_UserId",
                table: "PurchasedBooks");

            migrationBuilder.DropColumn(
                name: "UserId",
                table: "PurchasedBooks");

            migrationBuilder.AddColumn<string>(
                name: "UserName",
                table: "PurchasedBooks",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "UserName",
                table: "PurchasedBooks");

            migrationBuilder.AddColumn<string>(
                name: "UserId",
                table: "PurchasedBooks",
                type: "nvarchar(450)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_PurchasedBooks_UserId",
                table: "PurchasedBooks",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_PurchasedBooks_AspNetUsers_UserId",
                table: "PurchasedBooks",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
